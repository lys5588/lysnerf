mkdir -p logs
cd logs
wget http://cseweb.ucsd.edu/~viscomp/projects/LF/papers/ECCV20/nerf/fern_example_weights.zip
unzip fern_example_weights.zip
wget http://cseweb.ucsd.edu/~viscomp/projects/LF/papers/ECCV20/nerf/lego_example_weights.zip
unzip lego_example_weights.zip
